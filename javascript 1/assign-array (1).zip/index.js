//1.
//Given an array of integers: [3, 7, 12, 5, 9], calculate the sum of all elements.
{
  let arr=[3, 7, 12, 5, 9];
  let sum=0;
  for(let i=0;i<arr.length;i++){
    sum=(sum+arr[i]);
  }
  console.log(sum)
}


//2.
//Consider the array: [2, 4, 6, 8, 10]. Find the average (mean) of its elements.

{
  let arr=[2, 4, 6, 8, 10];
  let sum=0;
  for(let i=0;i<arr.length;i++){
    sum=(sum+arr[i]);
  }
  let avg=sum/arr.length;
  console.log(avg)
}

//3.
//If you have an array with elements [5, 10, 15, 20, 25], calculate the product of all elements.

{
  let arr=[5, 10, 15, 20, 25];
  let pro=1;
  for(let i=0;i<arr.length;i++){
    pro=(pro*arr[i]);
  }
  console.log(pro)
}

//4.
//Find the maximum element in the array: [17, 42, 8, 35, 21].

{
  let arr=[17, 42, 8, 35, 21];
  let max=0;
  for(let i=0;i<arr.length;i++){
    if(arr[i]>max){
      max=arr[i];
    }
  }
  console.log(max)
}

//5.
//Determine the minimum element in the array: [9, 14, 3, 27, 6].

{
  let arr=[9, 14, 3, 27, 6];
  let min=arr[0];
  for(let i=0;i<arr.length;i++){
    if(arr[i]<min){
      min=arr[i];
    }
  }
  console.log(min)
}

