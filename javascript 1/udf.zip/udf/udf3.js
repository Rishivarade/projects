//Create a function named calculateArea that calculates the area of a rectangle. It should take two parameters: length and width, and return the area.
//input:calculateArea(5, 3)
//output:15

function calCulateArea(len,wid){
    return len * wid
}
console.log(calCulateArea(5,3))