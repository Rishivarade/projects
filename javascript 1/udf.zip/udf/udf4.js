//Define a function named reverseString that takes a string as input and returns the reverse of that string.
//input:reverseString("hello")
//output:"olleh"

function reverseString(str){

    let rev=''
    for(let i=str.length-1; i>=0; i--)
    {rev+=str[i]}
    return rev
}
console.log(reverseString("hello"))