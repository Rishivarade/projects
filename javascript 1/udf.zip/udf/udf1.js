//Describe a function named greet that takes a parameter name and returns a greeting message. The greeting message should be "Hello, [name]!".
//input:greet("John")
//output:"Hello, John!"

function greet(name){
    return "Hello, " + name+"!"
}
console.log(greet('John'))