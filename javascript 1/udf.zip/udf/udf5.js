//Write a function named sumArray that takes an array of numbers as input and returns the sum of all the numbers in the array.
//input:sumArray([1, 2, 3, 4, 5])
//output:15

function sumArray(arr){
    let sum=0;
    for(let i of arr){
        sum+=i
    }
    return sum
}
console.log(sumArray([1,2,3,4,5,6]));