//Write a JavaScript program using a for loop that prints numbers from 1 to 5.
for (let i = 1; i<= 5;i++){
  console.log(i) 
}
console.log("---------")

//Create a JavaScript program using a while loop that prints numbers from 5 to 1.
for (let i = 5; i>= 1;i--){
  console.log(i)
}
console.log("---------")

//Write a JavaScript program using a for loop to calculate the sum of even numbers from 1 to 10.
let arr = [1,2,3,4,5,6,7,8,9,10]
let sum = 0
for (let i=0; i<arr.length; i++){
  if (arr[i]%2==0){
    sum += arr[i]
    console.log(sum)   
  }   
}
console.log("---------")

//Create a JavaScript program using a while loop to find the factorial of a given number.
let num = 5
let fact = 1
while (num>0){
  fact *= num
  num--
  console.log(fact)
}


//Develop a JavaScript program using nested for loops to create a pattern as shown 

for (let i = 1; i <= 5; i++) {
  let pattern = "";
  for (let j = 1; j <= i; j++) {
    pattern += "* ";
  }
  console.log(pattern);
}

  