//number is odd or even
{
  var number = 6
  if (number %2 == 0){
    console.log("number is even")
  }
  else {
    console.log("number is odd")
  }
}

//eligibility for vote
{
  var gender = "male";
  var age =22;
  if ((gender == "male") && (age >= 22)) {
    console.log("Eligible to vote");
  } 
  else {
    console.log("not eligible to vote")
  }
}

//check for vowel
{
  var char = "a";
  if (char == "a" || char == "e" || char == "i" || char == "o" || char == "u") {
    console.log("a is Vowel");
  } else {
    console.log("a is Not a vowel");
  }
}

//print the factorial of number
{
  let y = 5;
  let factorial = 1;

  for (let i = 1; i <= y; i++) {
    factorial *= i;
  }
  console.log("factorial =", factorial);
   
}


//sum of given number
{
  let num=12345
  let str = num.toString()
  let sum = 0
  for (let i=0; i<str.length;i++){
    sum += Number(str[i])
  }
  console.log("sum is =",sum)
  
}