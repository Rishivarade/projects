//You are given a string, stored in a variable named str. The size of the string is stored  You have to find the count of vowels and consonants in the string and print it.

// For example, consider the value stored in str = "nrupul", then the vowels, in

//Q-1 
// let str='nrupul';
// let count=0;
// let count1=0;
// for(let i=0;i<str.length;i++) {
//     if(str[i]=="a"||str[i]=="e"||str[i]=="i"||str[i]=="o"||str[i]=="u"){
//       count++
//     }
//     else{
//       count1++
//     }   
//   }
//  console.log(count,count1)


//Q-2
//Given an array arr , you need to print the smallest and largest element present in the array each on a new line.


// let arr=[3, 7, 2, 9, 1]
// let arr2= arr[0]
// let arr3= arr[0]
// for(let i=0;i<arr.length;i++){
//   if(arr2>arr[i]){
//     arr2=arr[i]
//   }
//   if(arr3<arr[i]){
//     arr3=arr[i]
//   }
// }
// console.log(arr2)
// console.log(arr3)

// //Q-3

//You are given two arrays arr1 and arr2 of  integers. Your task is to write a program that finds the one integer which is common in both arrays (arr1 and arr2).

// let arr1=[1 ,2 ,3 ,4 ,5]
// let arr2=[3 ,4 ,5 ,6 ,7]
// for(let i=0;i<arr1.length;i++){
//   for(let j=0;j<arr2.length;j++){
//     if(arr1[i]==arr2[j]){
//       bag++
//     }
    
//   }
// }
// console.log(bag)

// //Q-4
// //You are given a string ,the name str. You have to print all the characters in the string, which are present at odd indexes.

// let str="nrupul"
// for(let i=0;i<str.length;i++){
//   if(str[i]%2!=0){
//     console.log(str[i])
//   }
  
// }


// //Q-5
// //You are given an array of N integers. You need to print "Yes" if 42 is present in the array, else print "No".

// let arr=[ 10 ,20, 30, 40, 50, 42]
// let bag=""
// for(let i=0;i<arr.length;i++){
//   if(arr[i]==42){
//     bag="Yes"
//   }
//   else{
//     bag="No"
//   } 
// }
// console.log(bag)