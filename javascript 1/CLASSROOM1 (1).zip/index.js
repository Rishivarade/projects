//arithmetic operators
{
  var a = 10 + 5 * 2 - 3 / 2;
console.log(a);
}

//assignment operators
{
  let x = 5
   x += 3
  console.log(x)
}

//comparison operators
{
  const a = 10
  const b = 5
  const c = a > b
  console.log(c)
}

//logical operators
{
  const x = 5
  const y = 3
  const z = (x > 3) && (y < 2)
  console.log(z)
}

//grade calculation

{
  const subject1 = 85
  const subject2 = 90
  const avg = (subject1 + subject2) / 2
  if (avg >= 80 && avg <90){
    console.log("Grade A")
  }
  else if (avg >=70 && avg <80){
    console.log("Grade B")
  }
  else if (avg >= 60 && avg <70){
    console.log("Grade c")
  }
  else if (avg >=50 && avg <60){
    console.log("Grade D")
  }
  else{
    console.log("Grade F")
  }
}